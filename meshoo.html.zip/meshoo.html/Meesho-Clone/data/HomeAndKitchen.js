const HomeAndKitchen = [
    {
        heading : "Home Furnishing",
        data : ["Bedsheets","Doormats","Curtains & Sheers","Cushions & Cushion Covers","Mattress Protectors"]
    },
    {
        heading : "Home Decor",
        data : ["All Home Decor","Stickers","Clocks","Showpieces"]
    },
    {
        heading : "Kitchen & Dining",
        data : ["Kitchen Storage","Cookware & Bakeware"]
    },
]

export default HomeAndKitchen