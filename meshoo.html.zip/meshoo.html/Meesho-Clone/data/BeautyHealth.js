const BeautyHealth = [
    {
        heading : "Make up",
        data : ["Face","Eyes","Lips","Nails"]
    },
    {
        heading : "Wellness",
        data : ["Sanitizers","Oral Care","Feminine Hygiene"]
    },
    {
        heading : "Skincare",
        data : ["Deodorants"]
    },
]


export default BeautyHealth