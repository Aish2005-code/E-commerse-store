const Kids = [
    {
        heading : "Boys & Girls 2+ Years",
        data : ["Dresses"]
    },
    {
        heading : "Infant 0-2 Years",
        data : ["Rompers"]
    },
    {
        heading : "Toys & Accessories",
        data : ["Soft Toys","Footwear","Stationery","Watches","Bags & Backpacks"]
    },
    {
        heading : "Baby Care",
        data : ["All Baby Care"]
    },
]

export default Kids